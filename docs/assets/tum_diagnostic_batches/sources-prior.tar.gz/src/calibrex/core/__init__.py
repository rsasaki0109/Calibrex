"""Core Calibrex data structures."""
