"""Command-line interface package."""
