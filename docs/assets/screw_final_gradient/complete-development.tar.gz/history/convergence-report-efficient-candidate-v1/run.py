"""Private minimal reporting patch; verify covariance assembly reuse and state parity."""
from __future__ import annotations

import ast
import dataclasses
import difflib
import hashlib
import inspect
import json
import subprocess
import types
from datetime import datetime, timezone
from pathlib import Path

import jsonschema
import numpy as np
from pydantic import TypeAdapter

from calibrex.core import continuous_time_sparse as sparse
from calibrex.core.geometry import SE3

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = '350240593ad193478b2e09ed8c54435224c36a4c'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    path = OUT / name
    assert not path.exists(), path
    path.write_bytes((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
manifest_path = ROOT / 'docs/assets/prior_information_whitening/source-manifest.json'
expected = json.loads(manifest_path.read_bytes())


def manifest():
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes().replace(b'\r\n', b'\n')).hexdigest()
            for p in (ROOT / 'src/calibrex').rglob('*.py')}


assert manifest() == expected
original = sparse.fit_continuous_trajectory
source = inspect.getsource(original)
tree = ast.parse(source)
nodes = [node for node in tree.body[0].body if isinstance(node, ast.If)
         and ast.unparse(node.test) == "layout and status != 'singular_system'"]
assert len(nodes) == 1
node = nodes[0]
assert len(node.body) == 4 and isinstance(node.body[0], ast.Assign)
lines = source.splitlines(keepends=True)
replacement = ["    if status != \"singular_system\":\n"]
replacement.extend(lines[node.body[0].lineno - 1:node.body[0].end_lineno])
replacement.extend([
    '        final_weighted_jacobian = final_jacobian.multiply(final_weights[:, None])\n',
    '        final_rhs = final_weighted_jacobian.T @ (final_weights * final_residuals)\n',
    '        gradient_norm = float(np.max(np.abs(final_rhs)))\n',
    '        if layout:\n',
])
replacement.extend('    ' + line for line in lines[node.body[1].lineno - 1:node.end_lineno])
candidate_source = ''.join(lines[:node.lineno - 1] + replacement + lines[node.end_lineno:])
compile(candidate_source, 'private-efficient-report-candidate', 'exec')
candidate_path = OUT / 'candidate.py.txt'
assert not candidate_path.exists()
candidate_path.write_bytes(candidate_source.encode())
module_path = Path(sparse.__file__)
full_source = module_path.read_text(encoding='utf-8')
assert full_source.count(source) == 1
modified_source = full_source.replace(source, candidate_source)
patch = ''.join(difflib.unified_diff(full_source.splitlines(keepends=True), modified_source.splitlines(keepends=True),
                                   fromfile='a/src/calibrex/core/continuous_time_sparse.py',
                                   tofile='b/src/calibrex/core/continuous_time_sparse.py'))
assert not (OUT / 'candidate.patch').exists()
(OUT / 'candidate.patch').write_bytes(patch.encode())
origin = {'source_commit': SOURCE, 'created_at': datetime.now(timezone.utc).isoformat(),
          'generator': Path(__file__).name, 'launcher_sha256': sha(Path(__file__)),
          'source_manifest_sha256': sha(manifest_path), 'candidate_sha256': sha(candidate_path),
          'patch_sha256': sha(OUT / 'candidate.patch'),
          'role': 'private deterministic development diagnostic',
          'scope': 'Reporting only. Preserve stopping, objective, returned states and covariance. No source edit or performance/independent accuracy claim.'}
cases = [(calibration, budget) for calibration in (False, True) for budget in (1, 30)]
write('protocol.json', {'cases': [{'calibration': c, 'max_iterations': b} for c, b in cases], 'provenance': origin})
fit_schema = TypeAdapter(sparse.ContinuousTimeTrajectoryFitResult).json_schema()
fit_schema['properties']['provenance'] = {'type': 'object'}
fit_schema['required'].append('provenance')
write('fit.schema.json', fit_schema)
rows = []
errors = []
for calibration, budget in cases:
    name = f'calibration-{int(calibration)}-budget-{budget}'
    try:
        pose = SE3((1.5, 0., 0.), (0., 0., 0., 1.))
        problem = sparse.ContinuousTimeTrajectoryFitProblem(
            (0., 1.), (pose, pose),
            pose_measurements=tuple(sparse.TrajectoryPoseMeasurement(
                f'{t}-{x}', t, SE3((x, 0., 0.), (0., 0., 0., 1.)), w)
                for t in (0., 1.) for x, w in ((0., 1.), (2., 3.))),
            imu_preintegration_measurements=(sparse.TrajectoryImuPreintegrationMeasurement('gyro', (
                sparse.TrajectoryImuGyroSample(0., (0., 0., .2)),
                sparse.TrajectoryImuGyroSample(1., (0., 0., .2)),
            )),) if calibration else (), estimate_gyro_bias=calibration,
        )
        options = sparse.ContinuousTimeTrajectoryFitOptions(max_iterations=budget)
        outputs = []
        counts = []
        final_norms = []
        for variant in ('baseline', 'candidate'):
            assemblies = []

            def assembly(blocks, *, residual_count, parameter_count):
                matrix = sparse._assemble_sparse_jacobian(blocks, residual_count=residual_count, parameter_count=parameter_count)
                state = inspect.currentframe().f_back.f_locals
                weighted = matrix.multiply(state['weight_array'][:, None])
                assemblies.append(float(np.max(np.abs(weighted.T @ (state['weight_array'] * state['residual_array'])))))
                return matrix

            namespace = dict(vars(sparse), _assemble_sparse_jacobian=assembly)
            if variant == 'baseline':
                function = types.FunctionType(original.__code__, namespace, argdefs=original.__defaults__)
            else:
                exec(compile(candidate_source, str(candidate_path), 'exec'), namespace)
                function = namespace['fit_continuous_trajectory']
            result = function(problem, options)
            raw = dict(dataclasses.asdict(result), provenance=dict(origin, case=name, variant=variant))
            raw = json.loads(json.dumps(raw))
            jsonschema.validate(raw, fit_schema)
            write(name + '-' + variant + '.json', raw)
            outputs.append(dataclasses.asdict(result))
            counts.append(len(assemblies))
            final_norms.append(assemblies[-1])
        before, after = outputs
        before_gradient = before.pop('gradient_norm')
        after_gradient = after.pop('gradient_norm')
        row = {'case': name, 'all_other_result_fields_exactly_equal': before == after,
               'iterations': after['iterations'], 'status': after['status'],
               'baseline_assemblies': counts[0], 'candidate_assemblies': counts[1],
               'baseline_reported_gradient': before_gradient, 'candidate_reported_gradient': after_gradient,
               'candidate_final_model_gradient': final_norms[1],
               'candidate_reports_final_gradient': after_gradient == final_norms[1],
               'reuses_final_covariance_assembly': counts[1] == counts[0] if calibration else None}
        rows.append(row)
        assert before == after and row['candidate_reports_final_gradient']
        assert counts[1] == after['iterations'] + 1
        assert counts[0] == before['iterations'] + int(calibration)
        print(json.dumps(row), flush=True)
    except Exception as error:
        errors.append(f'{name}: {type(error).__name__}: {error}')
        print(errors[-1], flush=True)
record = {'status': 'PRIVATE_EFFICIENT_REPORTING_CANDIDATE_NOT_ADOPTED', 'cases': rows, 'exceptions': errors,
          'source_preserved': manifest() == expected,
          'limits': ['Four controlled cases only.', 'The premature stopping defect intentionally remains unchanged.',
                     'Assembly counts are structural evidence, not a runtime speed measurement.',
                     'A maintained production change still requires review and full regression/evaluation.'],
          'provenance': origin}
schema = {'type': 'object', 'required': list(record), 'additionalProperties': False,
          'properties': {'status': {'const': 'PRIVATE_EFFICIENT_REPORTING_CANDIDATE_NOT_ADOPTED'},
                         'cases': {'type': 'array', 'items': {'type': 'object'}},
                         'exceptions': {'type': 'array', 'items': {'type': 'string'}},
                         'source_preserved': {'type': 'boolean'}, 'limits': {'type': 'array', 'items': {'type': 'string'}},
                         'provenance': {'type': 'object'}}}
jsonschema.validate(record, schema)
write('result.schema.json', schema)
write('result.json', record)
assert not errors and len(rows) == 4 and record['source_preserved'], errors
