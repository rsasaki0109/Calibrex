"""Private deterministic final-gradient/stopping audit; no production edits."""
from __future__ import annotations

import dataclasses
import hashlib
import importlib.metadata
import json
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Any, Literal, get_type_hints

import jsonschema
import numpy as np
from pydantic import BaseModel, ConfigDict, Field, create_model
from scipy.spatial.transform import Rotation

from calibrex.core import continuous_time_sparse as sparse
from calibrex.core.geometry import SE3

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = "350240593ad193478b2e09ed8c54435224c36a4c"
ANCHORS = np.array([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.], [0., 0., 1.]])
TARGETS = ((0., 1.), (2., 3.))


def encode(value: Any) -> bytes:
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def write(name: str, value: Any) -> None:
    path = OUT / name
    assert not path.exists(), path
    path.write_bytes(encode(value))


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Provenance(Strict):
    source_commit: str
    source_manifest_sha256: str
    generator: str
    launcher_sha256: str
    created_at: str
    runtime: dict[str, str]
    seed: None
    role: Literal["private_deterministic_development_diagnostic"]
    scope: str


class Case(Strict):
    name: str
    initial_x: float
    max_iterations: int
    initial_damping: float


class Protocol(Strict):
    cases: list[Case]
    weighted_optimum_x: float
    weighted_optimum_objective: float
    finite_difference_epsilon: float
    gradient_convention: str
    independent_oracle: str
    provenance: Provenance


fields = {name: (annotation, ...) for name, annotation in
          get_type_hints(sparse.ContinuousTimeTrajectoryFitProblem).items()}
fields["knot_marginalization_priors"] = (Annotated[list[Any], Field(max_length=0)], ...)
ProblemSnapshot = create_model("ProblemSnapshot", __config__=ConfigDict(extra="forbid"), **fields)


class InputRecord(Strict):
    problem: ProblemSnapshot
    options: sparse.ContinuousTimeTrajectoryFitOptions
    provenance: Provenance


class FitRecord(Strict):
    payload: sparse.ContinuousTimeTrajectoryFitResult
    provenance: Provenance


class Observation(Strict):
    name: str
    status: str
    iterations: int
    stored_objective: float
    independent_objective: float
    objective_gap_to_closed_form_optimum: float
    reported_gradient_norm: float
    independent_final_half_gradient_norm: float
    reported_minus_final_gradient: float
    reported_gradient_matches_final: bool
    actual_final_stationary_at_declared_threshold: bool
    independent_half_gradient: Annotated[list[float], Field(min_length=12, max_length=12)]
    independent_normal_eigenvalue_min: float
    independent_normal_eigenvalue_max: float
    independent_undamped_step_translation_inf_m: float
    independent_undamped_step_rotation_inf_rad: float
    independent_gradient_finite_difference_max_abs_error: float
    max_translation_distance_to_optimum_m: float
    max_rotation_distance_to_optimum_rad: float
    max_accepted_translation_step_m: float
    source_preserved: bool


class Summary(Strict):
    status: Literal["PRIVATE_DIAGNOSTIC_COMPLETE_NOT_ADOPTED"]
    observations: list[Observation]
    exceptions: list[str]
    limits: list[str]
    provenance: Provenance


def checked(name: str, value: Any, model: type[BaseModel]) -> None:
    jsonschema.validate(value, model.model_json_schema())
    write(name, value)


def manifest() -> dict[str, str]:
    return {p.relative_to(ROOT).as_posix(): sha(p.read_bytes().replace(b"\r\n", b"\n"))
            for p in sorted((ROOT / "src/calibrex").rglob("*.py"))}


def skew(v: np.ndarray) -> np.ndarray:
    x, y, z = v
    return np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])


def rotation(q: tuple[float, float, float, float]) -> np.ndarray:
    x, y, z, w = np.asarray(q) / np.linalg.norm(q)
    return np.array([
        [1. - 2. * (y*y + z*z), 2. * (x*y - w*z), 2. * (x*z + w*y)],
        [2. * (x*y + w*z), 1. - 2. * (x*x + z*z), 2. * (y*z - w*x)],
        [2. * (x*z - w*y), 2. * (y*z + w*x), 1. - 2. * (x*x + y*y)],
    ])


def oracle(states: list[tuple[np.ndarray, np.ndarray]]) -> tuple[float, np.ndarray, np.ndarray]:
    """Direct four-anchor geometry, independent of production residual/Jacobian helpers."""
    objective = 0.
    gradient = np.zeros(12)
    normal = np.zeros((12, 12))
    for index, (rmat, translation) in enumerate(states):
        sl = slice(6*index, 6*index + 6)
        for target_x, weight in TARGETS:
            for anchor in ANCHORS:
                residual = rmat @ anchor + translation - anchor - np.array([target_x, 0., 0.])
                block = np.column_stack((rmat, -rmat @ skew(anchor)))
                objective += weight**2 * float(residual @ residual)
                gradient[sl] += weight**2 * block.T @ residual
                normal[sl, sl] += weight**2 * block.T @ block
    return objective, gradient, normal


def finite_gradient(states: list[tuple[np.ndarray, np.ndarray]], epsilon: float) -> np.ndarray:
    values = []
    for coordinate in range(12):
        index, axis = divmod(coordinate, 6)
        scores = []
        for sign in (1., -1.):
            updated = [(r.copy(), t.copy()) for r, t in states]
            rmat, translation = updated[index]
            direction = np.zeros(3)
            direction[axis % 3] = sign * epsilon
            updated[index] = ((rmat, translation + rmat @ direction) if axis < 3
                              else (rmat @ Rotation.from_rotvec(direction).as_matrix(), translation))
            scores.append(oracle(updated)[0])
        values.append((scores[0] - scores[1]) / (4. * epsilon))
    return np.array(values)


def main() -> None:
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip() == SOURCE
    before = manifest()
    expected = json.loads((ROOT / "docs/assets/prior_information_whitening/source-manifest.json").read_bytes())
    assert len(before) == 401 and before == expected
    write("source-manifest.json", before)
    provenance = Provenance(
        source_commit=SOURCE, source_manifest_sha256=sha(encode(before)),
        generator=Path(__file__).name, launcher_sha256=sha(Path(__file__).read_bytes()),
        created_at=datetime.now(timezone.utc).isoformat(),
        runtime={"python": platform.python_version(), **{p: importlib.metadata.version(p)
                 for p in ("numpy", "scipy", "pydantic", "jsonschema")}},
        seed=None, role="private_deterministic_development_diagnostic",
        scope="Deterministic spent development fixture. No production edits, timing, independent accuracy or SOTA claim.",
    ).model_dump(mode="json")
    for name, model in (("protocol", Protocol), ("input", InputRecord), ("fit", FitRecord), ("result", Summary)):
        write(name + ".schema.json", model.model_json_schema())
    cases = [
        Case(name="one-accepted-step", initial_x=1.5, max_iterations=1, initial_damping=1e-3),
        Case(name="default-budget", initial_x=1.5, max_iterations=30, initial_damping=1e-3),
        Case(name="large-damping-1e8", initial_x=1.5, max_iterations=60, initial_damping=1e8),
        Case(name="large-damping-1e12", initial_x=1.5, max_iterations=60, initial_damping=1e12),
        Case(name="two-steps-damping-one", initial_x=1.5, max_iterations=2, initial_damping=1.),
        Case(name="stationary-positive-control", initial_x=1.8, max_iterations=30, initial_damping=1e-3),
    ]
    protocol = Protocol(
        cases=cases, weighted_optimum_x=1.8, weighted_optimum_objective=28.8,
        finite_difference_epsilon=1e-6,
        gradient_convention="Stored gradient_norm is infinity norm of J.T W.T W r, half the squared-objective gradient.",
        independent_oracle="Two endpoint pose knots, each with four anchors and target translations 0/2 weighted 1/3. Direct geometry plus right-tangent derivatives; finite differences use independent Rodrigues rotations.",
        provenance=provenance,
    ).model_dump(mode="json")
    checked("protocol.json", protocol, Protocol)  # Declare every case before any fit.
    observations = []
    errors = []
    for case in cases:
        try:
            pose = SE3((case.initial_x, 0., 0.), (0., 0., 0., 1.))
            problem = sparse.ContinuousTimeTrajectoryFitProblem(
                (0., 1.), (pose, pose),
                pose_measurements=tuple(sparse.TrajectoryPoseMeasurement(
                    f"{index}-{target}", timestamp, SE3((target, 0., 0.), (0., 0., 0., 1.)), weight)
                    for index, timestamp in enumerate((0., 1.)) for target, weight in TARGETS),
            )
            options = sparse.ContinuousTimeTrajectoryFitOptions(max_iterations=case.max_iterations, initial_damping=case.initial_damping)
            checked(case.name + "-input.json", json.loads(encode({"problem": dataclasses.asdict(problem), "options": dataclasses.asdict(options), "provenance": provenance})), InputRecord)
            result = sparse.fit_continuous_trajectory(problem, options)
            checked(case.name + "-fit.json", json.loads(encode({"payload": dataclasses.asdict(result), "provenance": provenance})), FitRecord)
            states = [(rotation(knot.quaternion_xyzw), np.array(knot.translation_m)) for knot in result.knot_poses]
            objective, gradient, normal = oracle(states)
            final_norm = float(np.max(np.abs(gradient)))
            delta = np.linalg.solve(normal, -gradient).reshape(2, 6)
            eigenvalues = np.linalg.eigvalsh(normal)
            finite = finite_gradient(states, protocol["finite_difference_epsilon"])
            assert abs(result.final_objective - objective) < 1e-10
            assert float(np.max(np.abs(finite - gradient))) < 1e-7
            observation = Observation(
                name=case.name, status=result.status, iterations=result.iterations,
                stored_objective=result.final_objective, independent_objective=objective,
                objective_gap_to_closed_form_optimum=objective - 28.8,
                reported_gradient_norm=result.gradient_norm,
                independent_final_half_gradient_norm=final_norm,
                reported_minus_final_gradient=result.gradient_norm - final_norm,
                reported_gradient_matches_final=abs(result.gradient_norm - final_norm) < 1e-10,
                actual_final_stationary_at_declared_threshold=final_norm < options.convergence_gradient_norm,
                independent_half_gradient=gradient.tolist(),
                independent_normal_eigenvalue_min=float(eigenvalues[0]),
                independent_normal_eigenvalue_max=float(eigenvalues[-1]),
                independent_undamped_step_translation_inf_m=float(np.max(np.abs(delta[:, :3]))),
                independent_undamped_step_rotation_inf_rad=float(np.max(np.abs(delta[:, 3:]))),
                independent_gradient_finite_difference_max_abs_error=float(np.max(np.abs(finite - gradient))),
                max_translation_distance_to_optimum_m=max(float(np.linalg.norm(t - [1.8, 0., 0.])) for _, t in states),
                max_rotation_distance_to_optimum_rad=max(float(np.linalg.norm(Rotation.from_matrix(r).as_rotvec())) for r, _ in states),
                max_accepted_translation_step_m=result.max_step_translation_m,
                source_preserved=manifest() == before,
            ).model_dump(mode="json")
            observations.append(observation)
            print(json.dumps({k: observation[k] for k in ("name", "status", "iterations", "reported_gradient_norm", "independent_final_half_gradient_norm", "max_translation_distance_to_optimum_m")}), flush=True)
        except Exception as error:
            errors.append(f"{case.name}: {type(error).__name__}: {error}")
            print(errors[-1], flush=True)
    summary = Summary(
        status="PRIVATE_DIAGNOSTIC_COMPLETE_NOT_ADOPTED", observations=observations, exceptions=errors,
        limits=["Six fixed controlled cases only; no independent evaluation.",
                "No stopping thresholds or solver source changed.",
                "Large-damping cases deliberately stress a permitted option; frequency in real datasets is unknown.",
                "An undamped normal step diagnoses local remaining motion; it is not a globally valid proposed update.",
                "A convergence label can currently arise from either a gradient or accepted-step threshold."],
        provenance=provenance,
    ).model_dump(mode="json")
    checked("result.json", summary, Summary)
    assert manifest() == before
    assert not errors and len(observations) == len(cases), errors


if __name__ == "__main__":
    main()
