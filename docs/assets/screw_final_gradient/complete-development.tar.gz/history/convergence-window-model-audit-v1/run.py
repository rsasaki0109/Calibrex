"""Reassemble current final LiDAR-window models without taking optimization steps."""
from __future__ import annotations

import dataclasses
import hashlib
import importlib.util
import inspect
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import jsonschema
import numpy as np
from pydantic import BaseModel, ConfigDict

from calibrex.core import continuous_time_sparse as sparse
from calibrex.core.continuous_time_marginalization import KnotMarginalizationPrior
from calibrex.core.geometry import SE3
from calibrex.core.se3_manifold import se3_exp

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = '350240593ad193478b2e09ed8c54435224c36a4c'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    path = OUT / name
    assert not path.exists(), path
    path.write_bytes((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')


class Phase(Strict):
    phase: int
    input_sha256: str
    result_sha256: str
    recorded_status: str
    recorded_iterations: int
    stored_objective: float
    reassembled_objective: float
    stored_gradient_norm: float
    final_half_gradient_norm: float
    declared_gradient_threshold: float
    final_gradient_below_declared_threshold: bool
    undamped_translation_step_inf_m: float
    undamped_rotation_step_inf_rad: float
    declared_step_threshold: float
    undamped_step_below_declared_threshold: bool
    scaled_normal_rank: int
    scaled_normal_size: int
    scaled_normal_eigenvalue_min: float
    scaled_normal_eigenvalue_max: float
    normal_lstsq_relative_cutoff: float
    final_gradient_direction_fd_error: float
    max_reloaded_quaternion_change: float
    normal_record_sha256: str


class Result(Strict):
    status: str
    phases: list[Phase]
    exceptions: list[str]
    limits: list[str]
    provenance: dict[str, object]


def manifest():
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes().replace(b'\r\n', b'\n')).hexdigest()
            for p in (ROOT / 'src/calibrex').rglob('*.py')}


class Captured(BaseException):
    pass


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    expected = json.loads((ROOT / 'docs/assets/prior_information_whitening/source-manifest.json').read_bytes())
    assert manifest() == expected and len(expected) == 401
    helper = ROOT / 'outputs/prior-information-development-v1/run.py'
    spec = importlib.util.spec_from_file_location('frozen_prior_snapshot', helper)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    text, first = inspect.getsourcelines(sparse.fit_continuous_trajectory)
    locations = [first + index for index, line in enumerate(text)
                 if line.strip() == 'gradient_norm = float(np.max(np.abs(rhs)))']
    assert len(locations) == 1
    location = locations[0]
    origin = {'source_commit': SOURCE, 'created_at': datetime.now(timezone.utc).isoformat(),
              'generator': Path(__file__).name, 'launcher_sha256': sha(Path(__file__)),
              'source_manifest_sha256': sha(ROOT / 'docs/assets/prior_information_whitening/source-manifest.json'),
              'snapshot_helper_sha256': sha(helper), 'python_version': platform.python_version(),
              'role': 'private spent deterministic development diagnostic',
              'scope': 'Reassemble all three already-saved current window states; trace stops before the first solve. No solver source, thresholds, fits or historical results changed. No timing or independent accuracy claim.'}
    paths = [(ROOT / f'outputs/prior-information-development-v1/current/phase-{phase}/input.json',
              ROOT / f'outputs/prior-information-development-v1/current/phase-{phase}/fit-result.json')
             for phase in (0, 1, 2)]
    write('protocol.json', {'phases': [0, 1, 2], 'input_and_result_sha256': [[sha(a), sha(b)] for a, b in paths],
                            'capture_source_line': location, 'normal_lstsq_relative_cutoff': 1e-12,
                            'directional_fd_epsilon': 1e-6, 'provenance': origin})
    write('result.schema.json', Result.model_json_schema())
    model_schema = {'type': 'object', 'required': ['normal', 'half_gradient', 'provenance'],
                    'properties': {'normal': {'type': 'array', 'items': {'type': 'array', 'items': {'type': 'number'}}},
                                   'half_gradient': {'type': 'array', 'items': {'type': 'number'}},
                                   'provenance': {'type': 'object'}}, 'additionalProperties': False}
    write('normal.schema.json', model_schema)
    rows = []
    errors = []
    for phase, (input_path, result_path) in enumerate(paths):
        try:
            raw_input = json.loads(input_path.read_bytes())
            raw_result = json.loads(result_path.read_bytes())
            jsonschema.validate(raw_input, module.InputRecord.model_json_schema())
            jsonschema.validate(raw_result, module.FitRecord.model_json_schema())
            snapshot = module.ProblemSnapshot.model_validate(raw_input['payload']['problem'])
            args = {name: getattr(snapshot, name) for name in sparse.ContinuousTimeTrajectoryFitProblem.__dataclass_fields__}
            args['knot_marginalization_priors'] = tuple(KnotMarginalizationPrior(
                p.knot_index, p.anchor_pose, np.array(p.information)) for p in snapshot.knot_marginalization_priors)
            original = sparse.ContinuousTimeTrajectoryFitProblem(**args)
            assert not any(getattr(original, f) for f in args if f.startswith('estimate_'))
            saved = raw_result['payload']
            states = tuple(SE3(tuple(p['translation_m']), tuple(p['rotation_quat_xyzw'])) for p in saved['knot_poses'])
            problem = dataclasses.replace(original, initial_knot_poses=states)
            settings = sparse.ContinuousTimeTrajectoryFitOptions(**raw_input['payload']['options'])
            captured = []

            def trace(frame, event, argument):
                if frame.f_code is not sparse.fit_continuous_trajectory.__code__:
                    return None
                if event == 'line' and frame.f_lineno == location:
                    captured.append(dict(frame.f_locals))
                    raise Captured()
                return trace

            previous_trace = sys.gettrace()
            assert previous_trace is None
            sys.settrace(trace)
            try:
                sparse.fit_continuous_trajectory(problem, dataclasses.replace(settings, max_iterations=1))
                raise AssertionError('fit escaped the no-step capture')
            except Captured:
                pass
            finally:
                sys.settrace(previous_trace)
            assert len(captured) == 1
            state = captured[0]
            normal = state['normal'].toarray()
            gradient = np.asarray(state['rhs']).ravel()
            scale = np.sqrt(np.diag(normal))
            assert np.all(scale > 0.)
            scaled = normal / scale[:, None] / scale[None, :]
            z, _, rank, _ = np.linalg.lstsq(scaled, -gradient / scale, rcond=1e-12)
            delta = (z / scale).reshape(-1, 6)
            eigenvalues = np.linalg.eigvalsh(scaled)
            direction = -gradient / max(float(np.max(np.abs(gradient))), np.finfo(float).tiny)
            direction = direction.reshape(-1, 6)

            def score(multiplier):
                knots = [se3_exp(k, multiplier * d) for k, d in zip(states, direction, strict=True)]
                return sparse._objective(problem, state['point_rows'], state['plane_rows'], state['pose_rows'],
                    state['imu_rows'], state['lever_rows'], knots, state['gyro_bias'], state['lever_arm'],
                    state['clock_offset'], state['accel_bias'], state['gravity'], state['gyro_scale'], state['accel_scale'],
                    imu_rotation=sparse._imu_rotation_matrix(state['imu_rotation_vector']))

            epsilon = 1e-6
            numeric = (score(epsilon) - score(-epsilon)) / (2. * epsilon)
            analytic = 2. * float(gradient @ direction.ravel())
            normal_record = {'normal': normal.tolist(), 'half_gradient': gradient.tolist(),
                             'provenance': dict(origin, phase=phase, input_sha256=sha(input_path), result_sha256=sha(result_path))}
            jsonschema.validate(normal_record, model_schema)
            write(f'phase-{phase}-normal.json', normal_record)
            final_norm = float(np.max(np.abs(gradient)))
            row = Phase(
                phase=phase, input_sha256=sha(input_path), result_sha256=sha(result_path),
                recorded_status=saved['status'], recorded_iterations=saved['iterations'],
                stored_objective=saved['final_objective'], reassembled_objective=state['objective'],
                stored_gradient_norm=saved['gradient_norm'], final_half_gradient_norm=final_norm,
                declared_gradient_threshold=settings.convergence_gradient_norm,
                final_gradient_below_declared_threshold=final_norm < settings.convergence_gradient_norm,
                undamped_translation_step_inf_m=float(np.max(np.abs(delta[:, :3]))),
                undamped_rotation_step_inf_rad=float(np.max(np.abs(delta[:, 3:]))),
                declared_step_threshold=settings.convergence_step_norm,
                undamped_step_below_declared_threshold=float(np.max(np.abs(delta))) < settings.convergence_step_norm,
                scaled_normal_rank=int(rank), scaled_normal_size=len(gradient),
                scaled_normal_eigenvalue_min=float(eigenvalues[0]), scaled_normal_eigenvalue_max=float(eigenvalues[-1]),
                normal_lstsq_relative_cutoff=1e-12, final_gradient_direction_fd_error=abs(numeric - analytic),
                max_reloaded_quaternion_change=max(float(np.max(np.abs(np.array(k.rotation_quat_xyzw) - p['rotation_quat_xyzw'])))
                                                   for k, p in zip(states, saved['knot_poses'], strict=True)),
                normal_record_sha256=sha(OUT / f'phase-{phase}-normal.json'),
            ).model_dump(mode='json')
            rows.append(row)
            assert abs(row['stored_objective'] - row['reassembled_objective']) < 1e-10
            print(json.dumps(row), flush=True)
        except Exception as error:
            errors.append(f'phase-{phase}: {type(error).__name__}: {error}')
            print(errors[-1], flush=True)
    result = Result(status='PRIVATE_FINAL_WINDOW_MODEL_DIAGNOSTIC_NOT_ADOPTED', phases=rows, exceptions=errors,
                    limits=['All inputs and final states are already-spent development artifacts.',
                            'SE3 constructor renormalizes cached quaternions; the maximum byte-level value change is quantified.',
                            'Finite differences test the maintained objective along one declared direction per state.',
                            'Scaled least-squares rank cutoff is a diagnostic only, not a proposed stopping contract.',
                            'No new optimization steps, independent evaluation, timing or public quality-gate changes.'],
                    provenance=origin).model_dump(mode='json')
    jsonschema.validate(result, Result.model_json_schema())
    write('result.json', result)
    assert manifest() == expected
    assert not errors and len(rows) == 3, errors


if __name__ == '__main__':
    main()
