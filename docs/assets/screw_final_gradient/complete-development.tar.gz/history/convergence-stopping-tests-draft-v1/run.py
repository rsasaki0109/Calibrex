"""Retain all red/green draft outcomes with exact source and producer binding."""
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

import jsonschema

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = '350240593ad193478b2e09ed8c54435224c36a4c'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
manifest = json.loads((ROOT / 'docs/assets/prior_information_whitening/source-manifest.json').read_bytes())
actual = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes().replace(b'\r\n', b'\n')).hexdigest()
          for p in (ROOT / 'src/calibrex').rglob('*.py')}
assert actual == manifest and len(actual) == 401
test = OUT / 'test_stopping_contract.py'
xml = OUT / 'baseline.xml'
log = OUT / 'baseline.log'
assert not xml.exists() and not log.exists() and not (OUT / 'result.json').exists()
command = [sys.executable, '-m', 'pytest', str(test.relative_to(ROOT)), '-q', '-p', 'no:cacheprovider',
           '--junitxml', str(xml.relative_to(ROOT)), '--basetemp', str((OUT / 'pytest-tmp').relative_to(ROOT))]
with log.open('wb') as stream:
    completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
cases = list(ET.parse(xml).getroot().iter('testcase'))
counts = {"tests": len(cases), "failures": sum(c.find('failure') is not None for c in cases),
          "errors": sum(c.find('error') is not None for c in cases),
          "skipped": sum(c.find('skipped') is not None for c in cases)}
schema = {'$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'object',
          'required': ['status', 'source_commit', 'returncode', 'counts', 'artifacts_sha256', 'provenance'],
          'properties': {'status': {'const': 'PRIVATE_RED_TEST_DRAFT_NOT_ADOPTED'}, 'source_commit': {'type': 'string'},
                         'returncode': {'type': 'integer'}, 'counts': {'type': 'object', 'additionalProperties': {'type': 'integer'}},
                         'artifacts_sha256': {'type': 'object', 'additionalProperties': {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}},
                         'provenance': {'type': 'object'}}, 'additionalProperties': False}
record = {'status': 'PRIVATE_RED_TEST_DRAFT_NOT_ADOPTED', 'source_commit': SOURCE,
          'returncode': completed.returncode, 'counts': counts,
          'artifacts_sha256': {p.name: sha(p) for p in (test, xml, log)},
          'provenance': {'created_at': datetime.now(timezone.utc).isoformat(), 'generator': Path(__file__).name,
                         'launcher_sha256': sha(Path(__file__)), 'command': command,
                         'source_manifest_sha256': sha(ROOT / 'docs/assets/prior_information_whitening/source-manifest.json'),
                         'upstream_audit': 'outputs/convergence-report-audit-v2/result.json',
                         'upstream_audit_sha256': sha(ROOT / 'outputs/convergence-report-audit-v2/result.json'),
                         'role': 'private deterministic development diagnostic',
                         'scope': 'Expected red contract tests and two positive controls. No production change or independent evaluation.'}}
jsonschema.validate(record, schema)
(OUT / 'result.schema.json').write_bytes((json.dumps(schema, indent=2) + '\n').encode())
(OUT / 'result.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record, indent=2))
assert completed.returncode == 1 and counts == {'tests': 5, 'failures': 3, 'errors': 0, 'skipped': 0}
