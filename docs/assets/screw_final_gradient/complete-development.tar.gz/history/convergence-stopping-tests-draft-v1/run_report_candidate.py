"""Private report-only candidate; keep the separate premature stopping case red."""
from __future__ import annotations

import ast
import hashlib
import inspect
import json
import subprocess
import types
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pytest
import jsonschema

from calibrex.core import continuous_time_sparse as sparse

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = '350240593ad193478b2e09ed8c54435224c36a4c'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
expected = json.loads((ROOT / 'docs/assets/prior_information_whitening/source-manifest.json').read_bytes())


def manifest():
    return {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes().replace(b'\r\n', b'\n')).hexdigest()
            for p in (ROOT / 'src/calibrex').rglob('*.py')}


assert manifest() == expected
tree = ast.parse(inspect.getsource(sparse.fit_continuous_trajectory))
function = tree.body[0]
assert isinstance(function, ast.FunctionDef)
return_nodes = [i for i, node in enumerate(function.body) if isinstance(node, ast.Return)]
assert len(return_nodes) == 1
report = ast.parse('''
_report_blocks, _report_r, _report_w, _report_j = _linearize(
    knots, gyro_bias, lever_arm, clock_offset, accel_bias, gravity,
    gyro_scale, accel_scale, imu_rotation_vector,
)
_report_wj = _report_j.multiply(_report_w[:, None])
gradient_norm = float(np.max(np.abs(_report_wj.T @ (_report_w * _report_r))))
''').body
function.body[return_nodes[0]:return_nodes[0]] = report
ast.fix_missing_locations(tree)
candidate_source = ast.unparse(tree) + '\n'
candidate = OUT / 'report-candidate.py.txt'
assert not candidate.exists()
candidate.write_bytes(candidate_source.encode())
namespace = dict(vars(sparse))
exec(compile(tree, str(candidate), 'exec'), namespace)
original = sparse.fit_continuous_trajectory
candidate_function = namespace['fit_continuous_trajectory']
assert isinstance(candidate_function, types.FunctionType)
assert candidate_function.__defaults__ == original.__defaults__


class Evidence:
    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        outcome = yield
        result = outcome.get_result()
        if result.when == 'call':
            rows.append({'name': item.nodeid, 'outcome': result.outcome})


xml = OUT / 'report-candidate.xml'
assert not xml.exists() and not (OUT / 'report-candidate-result.json').exists()
rows = []
sparse.fit_continuous_trajectory = candidate_function
try:
    code = pytest.main([str((OUT / 'test_stopping_contract.py').relative_to(ROOT)), '-q',
                        '-p', 'no:cacheprovider', '--junitxml', str(xml.relative_to(ROOT)),
                        '--basetemp', str((OUT / 'pytest-candidate-tmp').relative_to(ROOT))],
                       plugins=[Evidence()])
finally:
    sparse.fit_continuous_trajectory = original
cases = list(ET.parse(xml).getroot().iter('testcase'))
counts = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
          'errors': sum(c.find('error') is not None for c in cases),
          'skipped': sum(c.find('skipped') is not None for c in cases)}
assert manifest() == expected
record = {'status': 'PRIVATE_REPORT_ONLY_CANDIDATE_NOT_ADOPTED', 'source_commit': SOURCE,
          'returncode': int(code), 'counts': counts, 'outcomes': rows,
          'reporting_tests_fixed': all(row['outcome'] == 'passed' for row in rows if 'gradient_report' in row['name']),
          'premature_stopping_test_remains_red': any(row['outcome'] == 'failed' and 'damping_alone' in row['name'] for row in rows),
          'source_preserved': True,
          'scope': 'Only append final-state gradient reassembly to an in-memory function. Deliberately no stopping change; no production edit, publication, performance or independent accuracy claim. A production patch should reuse covariance assembly instead of repeating it.',
          'provenance': {'created_at': datetime.now(timezone.utc).isoformat(), 'generator': Path(__file__).name,
                         'launcher_sha256': sha(Path(__file__)), 'candidate_sha256': sha(candidate),
                         'test_source_sha256': sha(OUT / 'test_stopping_contract.py'), 'junit_sha256': sha(xml),
                         'baseline_record_sha256': sha(OUT / 'result.json'),
                         'current_source_manifest_sha256': sha(ROOT / 'docs/assets/prior_information_whitening/source-manifest.json')}}
schema = {'$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'object',
          'required': list(record), 'additionalProperties': False,
          'properties': {'status': {'const': 'PRIVATE_REPORT_ONLY_CANDIDATE_NOT_ADOPTED'},
                         'source_commit': {'type': 'string'}, 'returncode': {'type': 'integer'},
                         'counts': {'type': 'object', 'additionalProperties': {'type': 'integer'}},
                         'outcomes': {'type': 'array', 'items': {'type': 'object', 'required': ['name', 'outcome'],
                                    'additionalProperties': False, 'properties': {'name': {'type': 'string'},
                                    'outcome': {'enum': ['passed', 'failed', 'skipped']}}}},
                         'reporting_tests_fixed': {'type': 'boolean'}, 'premature_stopping_test_remains_red': {'type': 'boolean'},
                         'source_preserved': {'type': 'boolean'}, 'scope': {'type': 'string'},
                         'provenance': {'type': 'object'}}}
jsonschema.validate(record, schema)
(OUT / 'report-candidate-result.schema.json').write_bytes((json.dumps(schema, indent=2) + '\n').encode())
(OUT / 'report-candidate-result.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record, indent=2))
assert int(code) == 1 and counts == {'tests': 5, 'failures': 1, 'errors': 0, 'skipped': 0}
assert record['reporting_tests_fixed'] and record['premature_stopping_test_remains_red']
