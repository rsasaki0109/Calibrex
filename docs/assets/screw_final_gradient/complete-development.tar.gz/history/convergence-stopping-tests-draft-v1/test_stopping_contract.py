"""Unadopted regression draft for independently observed stopping/reporting defects."""
from __future__ import annotations

import numpy as np
import pytest

from calibrex.core import continuous_time_sparse as sparse
from calibrex.core.geometry import SE3

ANCHORS = np.array([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.], [0., 0., 1.]])


def problem(x: float = 1.5) -> sparse.ContinuousTimeTrajectoryFitProblem:
    pose = SE3((x, 0., 0.), (0., 0., 0., 1.))
    return sparse.ContinuousTimeTrajectoryFitProblem(
        (0., 1.), (pose, pose),
        pose_measurements=tuple(
            sparse.TrajectoryPoseMeasurement(
                f"{timestamp}-{target}", timestamp,
                SE3((target, 0., 0.), (0., 0., 0., 1.)), weight,
            )
            for timestamp in (0., 1.) for target, weight in ((0., 1.), (2., 3.))
        ),
    )


def final_gradient_norm(knots: tuple[SE3, ...]) -> float:
    """Half-objective gradient from geometry, without production residual helpers."""
    values = []
    for knot in knots:
        x, y, z, w = knot.rotation_quat_xyzw
        rmat = np.array([
            [1 - 2*(y*y+z*z), 2*(x*y-w*z), 2*(x*z+w*y)],
            [2*(x*y+w*z), 1 - 2*(x*x+z*z), 2*(y*z-w*x)],
            [2*(x*z-w*y), 2*(y*z+w*x), 1 - 2*(x*x+y*y)],
        ])
        gradient = np.zeros(6)
        for target, weight in ((0., 1.), (2., 3.)):
            for anchor in ANCHORS:
                residual = rmat @ anchor + knot.translation_m - anchor - [target, 0., 0.]
                body_residual = rmat.T @ residual
                gradient[:3] += weight**2 * body_residual
                gradient[3:] += weight**2 * np.cross(anchor, body_residual)
        values.extend(gradient)
    return float(np.max(np.abs(values)))


@pytest.mark.parametrize("iterations,damping", [(1, 1e-3), (2, 1.)])
def test_gradient_report_belongs_to_returned_state(iterations: int, damping: float) -> None:
    result = sparse.fit_continuous_trajectory(problem(), sparse.ContinuousTimeTrajectoryFitOptions(
        max_iterations=iterations, initial_damping=damping,
    ))
    assert result.gradient_norm == pytest.approx(final_gradient_norm(result.knot_poses), abs=1e-10)


def test_damping_alone_does_not_certify_convergence_far_from_known_optimum() -> None:
    # Both accepted-step coordinates are tiny only because damping suppresses
    # them. A solver may report incomplete progress instead of exceeding budget.
    result = sparse.fit_continuous_trajectory(problem(), sparse.ContinuousTimeTrajectoryFitOptions(
        max_iterations=1, initial_damping=1e12,
    ))
    distance = max(float(np.linalg.norm(np.array(k.translation_m) - [1.8, 0., 0.]))
                   for k in result.knot_poses)
    assert result.status != "converged" or distance < 1e-8


@pytest.mark.parametrize("initial_x", [1.5, 1.8])
def test_stationary_positive_controls_keep_convergence(initial_x: float) -> None:
    result = sparse.fit_continuous_trajectory(problem(initial_x))
    assert result.status == "converged"
    assert final_gradient_norm(result.knot_poses) < 1e-8
    for knot in result.knot_poses:
        np.testing.assert_allclose(knot.translation_m, [1.8, 0., 0.], atol=1e-8)


@pytest.fixture(scope="session", autouse=True)
def provenance(record_testsuite_property):
    record_testsuite_property("source_commit", "350240593ad193478b2e09ed8c54435224c36a4c")
    record_testsuite_property("scope", "private draft regression, no production change or independent evaluation")
