"""Bind the final 24 maintained tests to the frozen numerical source."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = 'aa4a0c24069020624e4d6bb8c519c2d9d9838fcd'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
test = ROOT / 'tests/unit/test_continuous_time_final_gradient.py'
xml = OUT / 'current-tests.xml'
log = OUT / 'current-tests.log'
assert not xml.exists() and not log.exists() and not (OUT / 'current-tests.json').exists()
command = [sys.executable, '-m', 'pytest', str(test.relative_to(ROOT)), '-q', '-p', 'no:cacheprovider',
           '--junitxml', str(xml.relative_to(ROOT)), '--basetemp', str((OUT / 'current-tests-tmp').relative_to(ROOT))]
with log.open('wb') as stream:
    completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
cases = list(ET.parse(xml).getroot().iter('testcase'))
counts = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
          'errors': sum(c.find('error') is not None for c in cases), 'skipped': sum(c.find('skipped') is not None for c in cases)}
raw_test = test.read_bytes().replace(b'\r\n', b'\n')
old = json.loads((OUT / 'baseline-tests.json').read_bytes())
assert hashlib.sha256(raw_test).hexdigest() == old['provenance']['test_source_sha256']
record = {'counts': counts, 'returncode': completed.returncode, 'provenance': {
    'source_commit': SOURCE, 'created_at': datetime.now(timezone.utc).isoformat(),
    'generator': Path(__file__).name, 'launcher_sha256': sha(Path(__file__)),
    'test_source_sha256': hashlib.sha256(raw_test).hexdigest(), 'junit_sha256': sha(xml),
    'log_sha256': sha(log), 'role': 'maintained deterministic regression', 'command': command}}
(OUT / 'current-tests.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record, indent=2))
assert completed.returncode == 0 and counts == {'tests': 24, 'failures': 0, 'errors': 0, 'skipped': 0}
