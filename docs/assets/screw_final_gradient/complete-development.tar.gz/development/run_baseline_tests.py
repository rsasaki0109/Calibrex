"""Run the exact final tests against the unchanged preceding fit function."""
from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import types
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

import pytest

from calibrex.core import continuous_time_sparse as sparse

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BASE = '1e6da103bf1d268d6469cb60dce269099dae53ea'
path = 'src/calibrex/core/continuous_time_sparse.py'
old = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
snapshot = OUT / 'baseline-source.py.txt'
assert not snapshot.exists()
snapshot.write_bytes(old)
parsed = ast.parse(old)
functions = [n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == 'fit_continuous_trajectory']
assert len(functions) == 1
current = ast.parse((ROOT / path).read_bytes())
for node in parsed.body:
    if isinstance(node, ast.FunctionDef) and node.name != 'fit_continuous_trajectory':
        matching = [n for n in current.body if isinstance(n, ast.FunctionDef) and n.name == node.name]
        assert len(matching) == 1 and ast.dump(node, include_attributes=False) == ast.dump(matching[0], include_attributes=False)
namespace = dict(vars(sparse))
exec(compile(ast.Module(body=functions, type_ignores=[]), str(snapshot), 'exec'), namespace)
original = sparse.fit_continuous_trajectory
baseline = types.FunctionType(namespace['fit_continuous_trajectory'].__code__, vars(sparse), argdefs=original.__defaults__)
test = ROOT / 'tests/unit/test_continuous_time_final_gradient.py'
xml = OUT / 'baseline-tests.xml'
assert not xml.exists()
sparse.fit_continuous_trajectory = baseline
try:
    code = pytest.main([str(test.relative_to(ROOT)), '-q', '-p', 'no:cacheprovider',
                        '--junitxml', str(xml.relative_to(ROOT)),
                        '--basetemp', str((OUT / 'baseline-tests-tmp').relative_to(ROOT))])
finally:
    sparse.fit_continuous_trajectory = original
cases = list(ET.parse(xml).getroot().iter('testcase'))
counts = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
          'errors': sum(c.find('error') is not None for c in cases),
          'skipped': sum(c.find('skipped') is not None for c in cases)}
record = {'counts': counts, 'returncode': int(code), 'provenance': {
    'source_commit': BASE, 'generator': Path(__file__).name,
    'launcher_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'created_at': datetime.now(timezone.utc).isoformat(),
    'baseline_source_sha256': hashlib.sha256(old).hexdigest(),
    'test_source_sha256': hashlib.sha256(test.read_bytes().replace(b'\r\n', b'\n')).hexdigest(),
    'junit_sha256': hashlib.sha256(xml.read_bytes()).hexdigest(),
    'role': 'already-spent deterministic development regression',
    'scope': 'Unchanged old fit function with the unchanged current helper namespace; monkeypatches used by tests still address that namespace.'}}
(OUT / 'baseline-tests.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record, indent=2))
assert int(code) == 1 and counts == {'tests': 24, 'failures': 15, 'errors': 0, 'skipped': 0}
