"""Private same-input sliding-window test of equilibrated prior whitening."""
from __future__ import annotations
import ast
import dataclasses
import hashlib
import importlib.util
import json
import subprocess
import sys
import traceback
import types
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import jsonschema
import numpy as np
from pydantic import BaseModel, ConfigDict, TypeAdapter
from calibrex.core import continuous_time_sparse as sparse
from calibrex.core import continuous_time_sliding_window_fit as sliding
from calibrex.core.se3_manifold import se3_exp, se3_log
from calibrex.evaluation.continuous_time_lidar_point_to_plane import _measurements,_truth_knots

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
SOURCE='8861ed65ebbcffb13a182ac4cd549db88ef763f2'
HELPER=ROOT/'outputs/prior-equilibrated-policy-audit-v1/probe.py'


def sha(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()


def serializable(value):
 if isinstance(value,np.ndarray): return value.tolist()
 raise TypeError(type(value).__name__)


def write(name,value):
 path=OUT/name; assert not path.exists(),path
 path.parent.mkdir(parents=True,exist_ok=True)
 path.write_bytes((json.dumps(value,indent=2,allow_nan=False,default=serializable)+'\n').encode())


class Envelope(BaseModel):
 model_config=ConfigDict(extra='forbid')
 payload: dict[str,Any]
 provenance: dict[str,Any]


def clone(function,namespace):
 result=types.FunctionType(function.__code__,namespace,argdefs=function.__defaults__)
 result.__kwdefaults__=function.__kwdefaults__
 return result


def score(problem,result):
 timestamps=problem.knot_timestamps
 return sparse._objective(problem,
  [(sparse._interval_index(timestamps,m.timestamp_sec),m.point_body_m) for m in problem.point_measurements],
  [(sparse._interval_index(timestamps,m.timestamp_sec),m) for m in problem.point_to_plane_measurements],
  [(sparse._interval_index(timestamps,m.timestamp_sec),m.pose_world_body) for m in problem.pose_measurements],[],[],
  list(result.knot_poses),np.zeros(3),np.zeros(3),0.,np.zeros(3),np.zeros(3),np.ones(3),np.ones(3))


assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
original={p.relative_to(ROOT).as_posix():sha(p) for p in (ROOT/'src/calibrex').rglob('*.py')}
definitions=[n for n in ast.parse(HELPER.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef) and n.name=='factor']
assert len(definitions)==1
namespace={'np':np}; exec(compile(ast.Module(body=definitions,type_ignores=[]),str(HELPER),'exec'),namespace)
checked_factor=namespace['factor']
spec=importlib.util.spec_from_file_location('private_prior_blocks_for_window',ROOT/'outputs/prior-production-screen-v1/probe.py')
helper=importlib.util.module_from_spec(spec); sys.modules[spec.name]=helper; spec.loader.exec_module(helper)
blocks=clone(helper.candidate_blocks,dict(vars(helper),candidate_factor=lambda matrix:checked_factor(matrix)[0]))
origin={'source_commit':SOURCE,'created_at':datetime.now(timezone.utc).isoformat(),'generator':Path(__file__).name,
 'launcher_sha256':sha(Path(__file__)),'source_files_raw_sha256':original,'factor_source_sha256':sha(HELPER),
 'block_source_sha256':sha(ROOT/'outputs/prior-production-screen-v1/probe.py'),
 'scope':'Private in-memory weighting only, existing spent unit fixture, all outcomes retained, no timing or independent accuracy claim'}
write('protocol.json',{'fixture':'test_sliding_window_matches_batch_overlap, seed 7','implementations':['production','candidate'],
 'max_iterations':80,'window_knot_counts':[4,3],'overlap_knot_count':1,
 'input_and_options_same_for_both':True,'known_limits':['Marginalized gradients/cross-block semantics unchanged','No holdout or known-bad control in this fixture','Returned sliding aggregate metadata copies some batch fields; per-window fit records are retained separately'],
 'provenance':origin})
write('envelope.schema.json',Envelope.model_json_schema())
timestamps=tuple(float(i) for i in range(6)); truth=_truth_knots(timestamps)
rng=np.random.default_rng(7)
samples=[(float(rng.uniform(.05,4.95)),int(i%3)) for i in range(90)]
measurements=_measurements(truth,timestamps,samples,rng,prefix='train')
initial=tuple(se3_exp(knot,np.array([.02,-.01,.01,0.,0.,.01])) for knot in truth)
problem=sparse.ContinuousTimeTrajectoryFitProblem(knot_timestamps=timestamps,initial_knot_poses=initial,point_to_plane_measurements=measurements)
options=sparse.ContinuousTimeTrajectoryFitOptions(max_iterations=80)
write('input.json',{'payload':{'problem':dataclasses.asdict(problem),'options':dataclasses.asdict(options)},'provenance':origin})
rows=[]
for implementation in ('production','candidate'):
 provenance=dict(origin,implementation=implementation)
 phases=[]; retained=[]
 fit=clone(sparse.fit_continuous_trajectory,dict(vars(sparse),marginalization_prior_blocks=blocks)) if implementation=='candidate' else sparse.fit_continuous_trajectory
 dense=clone(sparse.build_dense_knot_normal_equations,dict(vars(sparse),marginalization_prior_blocks=blocks)) if implementation=='candidate' else sparse.build_dense_knot_normal_equations
 def fit_and_retain(local_problem,local_options):
  phase=str(len(phases)); folder=implementation+'/phase-'+phase
  write(folder+'/input.json',{'payload':{'problem':dataclasses.asdict(local_problem),'options':dataclasses.asdict(local_options)},'provenance':provenance})
  result=fit(local_problem,local_options)
  write(folder+'/fit-result.json',{'payload':dataclasses.asdict(result),'provenance':provenance})
  payload_schema=TypeAdapter(type(result)).json_schema()
  schema={'type':'object','additionalProperties':False,'required':['payload','provenance'],
   'properties':{'payload':payload_schema,'provenance':{'type':'object'}}}
  if '$defs' in payload_schema: schema['$defs']=payload_schema.pop('$defs')
  write(folder+'/fit-result.schema.json',schema)
  jsonschema.validate(json.loads((OUT/folder/'fit-result.json').read_text()),schema)
  item={'phase':phase,'status':result.status,'iterations':result.iterations,'stored_final_objective':result.final_objective,
    'recomputed_declared_objective':score(local_problem,result),'prior_count':len(local_problem.knot_marginalization_priors)}
  phases.append(item)
  return result
 def retain_split(hessian,gradient,**kwargs):
  retained.append({'information':hessian.tolist(),'gradient':gradient.tolist(),'rank':int(np.linalg.matrix_rank(hessian)),
   'information_norm_inf':float(np.linalg.norm(hessian,ord=np.inf)),'gradient_inf':float(np.max(np.abs(gradient))),
   'retained_knot_count':kwargs['retained_knot_count']})
  return sliding.split_retained_information(hessian,gradient,**kwargs)
 private_sliding=clone(sliding.fit_sliding_window_trajectory,dict(vars(sliding),
  fit_continuous_trajectory=fit_and_retain,build_dense_knot_normal_equations=dense,split_retained_information=retain_split))
 try:
  result=private_sliding(problem,window_knot_counts=(4,3),overlap_knot_count=1,options=options)
  translations=[np.linalg.norm(np.array(a.translation_m)-np.array(b.translation_m)) for a,b in zip(truth,result.sliding_result.knot_poses,strict=True)]
  rotations=[np.linalg.norm(se3_log(a,b)[3:]) for a,b in zip(truth,result.sliding_result.knot_poses,strict=True)]
  payload={'outcome':'complete','batch_status':result.batch_result.status,'sliding_status':result.sliding_result.status,
   'max_overlap_translation_error_m':result.max_overlap_translation_error_m,'max_overlap_rotation_error_rad':result.max_overlap_rotation_error_rad,
   'same_existing_unit_gate_pass':result.batch_result.status=='converged' and result.max_overlap_translation_error_m<.05,
   'max_truth_translation_error_m':float(max(translations)),'max_truth_rotation_error_rad':float(max(rotations)),
   'aggregate_sliding_stored_objective':result.sliding_result.final_objective,'phases':phases,'retained_inputs':retained}
 except Exception as error:
  payload={'outcome':'exception','error':repr(error),'traceback':traceback.format_exc(),'phases':phases,'retained_inputs':retained}
 row={'payload':payload,'provenance':provenance}; write(implementation+'/outcome.json',row)
 jsonschema.validate(row,Envelope.model_json_schema()); rows.append(row)
 print(json.dumps({'implementation':implementation,**{k:v for k,v in payload.items() if k not in ('traceback','retained_inputs')}}),flush=True)
assert original=={p.relative_to(ROOT).as_posix():sha(p) for p in (ROOT/'src/calibrex').rglob('*.py')}
write('outcomes.json',{'payload':{'outcomes':rows,'source_unchanged':True},'provenance':origin})
