"""Package fixed CPU evidence without input data, caches or archived execution."""

import hashlib
import json
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pack(folder, destination):
    paths = {}
    for name in ("source", "toolchain", "schemas"):
        for path in (folder / name).rglob("*"):
            if path.is_file():
                paths[path.relative_to(folder).as_posix()] = path
    for name in ("protocol.json", "attempts.json", "comparison.json", "receipt.json"):
        paths[name] = folder / name
    attempts = json.loads((folder / "attempts.json").read_bytes())
    for observation in attempts["observations"]:
        worker = observation["worker"]
        for name in ("config.json", "result.json", "measurement.json"):
            paths[f"{worker}/{name}"] = folder / worker / name
        for kind in ("stdout", "stderr"):
            name = f"{worker}-{kind}.txt"
            paths[name] = folder / name
    paths["publication/pack.py"] = Path(__file__).resolve()
    paths["publication/LICENSE"] = Path("LICENSE").resolve()
    protocol = json.loads((folder / "protocol.json").read_bytes())
    index = {
        "kind": "indexed_online_edge_cpu_evidence/v0.1",
        "files": {
            name: {"size": path.stat().st_size, "sha256": sha(path)}
            for name, path in sorted(paths.items())
        },
        "provenance": {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "source_commit": protocol["source_commit"],
            "protocol_sha256": sha(folder / "protocol.json"),
            "publisher_sha256": sha(Path(__file__)),
            "raw_inputs_included": False,
            "scope": "Byte-indexed execution evidence, retaining all original workers",
        },
    }
    index_path = folder / "index.json"
    index_path.write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    paths["index.json"] = index_path
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(destination, "w:gz", compresslevel=9) as archive:
        for name, path in sorted(paths.items()):
            archive.add(path, arcname=name, recursive=False)
    print(json.dumps({
        "archive": str(destination), "bytes": destination.stat().st_size,
        "sha256": sha(destination), "indexed_files": len(index["files"]),
    }))


if __name__ == "__main__":
    pack(Path(sys.argv[1]), Path(sys.argv[2]))
