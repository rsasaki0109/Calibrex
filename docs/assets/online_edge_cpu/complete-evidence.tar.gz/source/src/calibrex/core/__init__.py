"""Core Calibrex data structures."""
