"""Optional fused CPU plane residual/Jacobian evaluator for the joint spline fit.

Small SO(3) temporaries are reused within a serial, nogil kernel. Scalar array
access avoids creating per-return views and reduces JIT compilation overhead. Independent
row slices run in Python threads; Numba's automatic parallel pass is disabled.
"""

from __future__ import annotations

import math
from concurrent.futures import ThreadPoolExecutor
from importlib.metadata import version
from typing import TYPE_CHECKING, TypeAlias, cast

import numpy as np
from numba import njit
from numpy.typing import NDArray
from scipy.sparse import bmat, coo_matrix, csc_matrix

from calibrex.core.continuous_time_bspline import (
    CubicBSplineTrajectory,
    cumulative_basis,
    so3_log_batch,
)
from calibrex.core.continuous_time_bspline_derivatives import _right_jacobian

if TYPE_CHECKING:
    from calibrex.core.continuous_time_bspline_fit import BSplinePlaneReturns, _Linearization

FloatArray: TypeAlias = NDArray[np.float64]
IntArray: TypeAlias = NDArray[np.int64]


@njit(inline="always", fastmath=False)  # type: ignore[untyped-decorator]
def _multiply(a: FloatArray, b: FloatArray, out: FloatArray) -> None:
    for i in range(3):
        for j in range(3):
            out[i, j] = (a[i, 0] * b[0, j] + a[i, 1] * b[1, j]) + a[i, 2] * b[2, j]


@njit(inline="always", fastmath=False)  # type: ignore[untyped-decorator]
def _exponential(
    v: FloatArray, step: FloatArray, jr: FloatArray, k: FloatArray, kk: FloatArray, slot: int
) -> None:
    squared = (v[0] * v[0] + v[1] * v[1]) + v[2] * v[2]
    angle = math.sqrt(squared)
    if angle < 1e-8:
        a = 1.0 - squared / 6.0
        b = 0.5 - squared / 24.0
    else:
        a = math.sin(angle) / angle
        b = (1.0 - math.cos(angle)) / squared
    if squared < 1e-8:
        ja = 0.5 - squared / 24.0 + squared * squared / 720.0
        jb = 1.0 / 6.0 - squared / 120.0 + squared * squared / 5040.0
    else:
        ja = (1.0 - math.cos(angle)) / squared
        jb = (angle - math.sin(angle)) / (squared * angle)
    k[0, 0] = 0
    k[0, 1] = -v[2]
    k[0, 2] = v[1]
    k[1, 0] = v[2]
    k[1, 1] = 0
    k[1, 2] = -v[0]
    k[2, 0] = -v[1]
    k[2, 1] = v[0]
    k[2, 2] = 0
    _multiply(k, k, kk)
    for i in range(3):
        for j in range(3):
            identity = 1.0 if i == j else 0.0
            step[slot, i, j] = (identity + a * k[i, j]) + b * kk[i, j]
            jr[slot, i, j] = (identity - ja * k[i, j]) + jb * kk[i, j]


@njit(cache=True, nogil=True, fastmath=False)  # type: ignore[untyped-decorator]
def _plane_kernel(
    rotations: FloatArray,
    positions: FloatArray,
    segment: IntArray,
    basis: FloatArray,
    relative: FloatArray,
    delta: FloatArray,
    log_jacobian: FloatArray,
    points: FloatArray,
    anchors: FloatArray,
    normals: FloatArray,
    sigma: float,
    derivatives: bool,
) -> tuple[FloatArray, FloatArray]:
    n = len(segment)
    residual = np.empty(n)
    jacobian = np.empty((n, 24)) if derivatives else np.empty((0, 24))
    rotation = np.empty((3, 3))
    position = np.empty(3)
    steps = np.empty((3, 3, 3))
    jrs = np.empty((3, 3, 3))
    v = np.empty(3)
    k = np.empty((3, 3))
    kk = np.empty((3, 3))
    tangent = np.empty((3, 12))
    suffix = np.empty((3, 3))
    scratch = np.empty((3, 3))
    scratch2 = np.empty((3, 3))
    block = np.empty((3, 3))
    previous = np.empty((3, 3))
    world_derivative = np.empty((3, 3))
    for row in range(n):
        s = segment[row]
        for a in range(3):
            for b in range(3):
                rotation[a, b] = rotations[s, a, b]
        for a in range(3):
            position[a] = positions[s, a]
        for slot in range(1, 4):
            for a in range(3):
                v[a] = basis[row, slot] * delta[s + slot - 1, a]
            _exponential(v, steps, jrs, k, kk, slot - 1)
            for i in range(3):
                for j in range(3):
                    scratch[i, j] = (
                        rotation[i, 0] * steps[slot - 1, 0, j]
                        + rotation[i, 1] * steps[slot - 1, 1, j]
                    ) + rotation[i, 2] * steps[slot - 1, 2, j]
            for a in range(3):
                for b in range(3):
                    rotation[a, b] = scratch[a, b]
            for a in range(3):
                position[a] += basis[row, slot] * (
                    positions[s + slot, a] - positions[s + slot - 1, a]
                )
        r = 0.0
        for a in range(3):
            world = (rotation[a, 0] * points[row, 0] + rotation[a, 1] * points[row, 1]) + rotation[
                a, 2
            ] * points[row, 2]
            r += normals[row, a] * ((world + position[a]) - anchors[row, a])
        residual[row] = r / sigma
        if not derivatives:
            continue
        for a in range(3):
            for b in range(12):
                tangent[a, b] = 0.0
        for a in range(3):
            for b in range(3):
                suffix[a, b] = 1.0 if a == b else 0.0
        for slot in range(3, 0, -1):
            edge = s + slot - 1
            for i in range(3):
                for j in range(3):
                    scratch[i, j] = (
                        suffix[i, 0] * jrs[slot - 1, 0, j] + suffix[i, 1] * jrs[slot - 1, 1, j]
                    ) + suffix[i, 2] * jrs[slot - 1, 2, j]
            for i in range(3):
                for j in range(3):
                    scratch2[i, j] = (
                        scratch[i, 0] * log_jacobian[edge, 0, j]
                        + scratch[i, 1] * log_jacobian[edge, 1, j]
                    ) + scratch[i, 2] * log_jacobian[edge, 2, j]
            for a in range(3):
                for b in range(3):
                    block[a, b] = scratch2[a, b] * basis[row, slot]
            for i in range(3):
                for j in range(3):
                    previous[i, j] = (
                        block[i, 0] * relative[edge, j, 0] + block[i, 1] * relative[edge, j, 1]
                    ) + block[i, 2] * relative[edge, j, 2]
            for a in range(3):
                for b in range(3):
                    tangent[a, 3 * slot + b] += block[a, b]
                    tangent[a, 3 * (slot - 1) + b] -= previous[a, b]
            for i in range(3):
                for j in range(3):
                    scratch[i, j] = (
                        suffix[i, 0] * steps[slot - 1, j, 0] + suffix[i, 1] * steps[slot - 1, j, 1]
                    ) + suffix[i, 2] * steps[slot - 1, j, 2]
            for a in range(3):
                for b in range(3):
                    suffix[a, b] = scratch[a, b]
        for a in range(3):
            for b in range(3):
                tangent[a, b] += suffix[a, b]
        for a in range(3):
            v[a] = points[row, a]
        k[0, 0] = 0
        k[0, 1] = -v[2]
        k[0, 2] = v[1]
        k[1, 0] = v[2]
        k[1, 1] = 0
        k[1, 2] = -v[0]
        k[2, 0] = -v[1]
        k[2, 1] = v[0]
        k[2, 2] = 0
        _multiply(rotation, k, scratch)
        for a in range(3):
            for b in range(3):
                world_derivative[a, b] = -scratch[a, b]
        for slot in range(4):
            weight = basis[row, slot] - (basis[row, slot + 1] if slot < 3 else 0.0)
            for axis in range(3):
                jacobian[row, 6 * slot + axis] = (normals[row, axis] / sigma) * weight
                derivative = 0.0
                for a in range(3):
                    value = (
                        world_derivative[a, 0] * tangent[0, 3 * slot + axis]
                        + world_derivative[a, 1] * tangent[1, 3 * slot + axis]
                    ) + world_derivative[a, 2] * tangent[2, 3 * slot + axis]
                    derivative += normals[row, a] * value
                jacobian[row, 6 * slot + 3 + axis] = derivative / sigma
    return residual, jacobian


@njit(cache=True, nogil=True, fastmath=False)  # type: ignore[untyped-decorator]
def _plane_normal(
    segment: IntArray, local: FloatArray, residual: FloatArray, controls: int,
) -> tuple[FloatArray, FloatArray]:
    band = np.zeros((controls, 7, 6, 6))
    gradient = np.zeros(6 * controls)
    for row in range(len(segment)):
        for a in range(24):
            control = segment[row] + a // 6
            axis = a % 6
            value = local[row, a]
            gradient[6 * control + axis] += value * residual[row]
            for b in range(24):
                offset = b // 6 - a // 6 + 3
                band[control, offset, axis, b % 6] += value * local[row, b]
    return band, gradient


@njit(cache=True, nogil=True, fastmath=False)  # type: ignore[untyped-decorator]
def _imu_normal(
    columns: IntArray, values: FloatArray, residual: FloatArray, controls: int,
    parameters: int, local_columns: int,
) -> tuple[FloatArray, FloatArray, FloatArray, FloatArray]:
    control_columns = 6 * controls
    calibration_columns = parameters - control_columns
    band = np.zeros((controls, 7, 6, 6))
    coupling = np.zeros((control_columns, calibration_columns))
    calibration = np.zeros((calibration_columns, calibration_columns))
    gradient = np.zeros(parameters)
    for row in range(len(values)):
        for a in range(local_columns):
            i = columns[row, a]
            value = values[row, a]
            gradient[i] += value * residual[row]
            for b in range(local_columns):
                j = columns[row, b]
                band[i // 6, j // 6 - i // 6 + 3, i % 6, j % 6] += value * values[row, b]
            for b in range(local_columns, values.shape[1]):
                j = columns[row, b] - control_columns
                coupling[i, j] += value * values[row, b]
        for a in range(local_columns, values.shape[1]):
            i = columns[row, a] - control_columns
            value = values[row, a]
            gradient[control_columns + i] += value * residual[row]
            for b in range(local_columns, values.shape[1]):
                j = columns[row, b] - control_columns
                calibration[i, j] += value * values[row, b]
    return band, coupling, calibration, gradient


class _NumbaPlaneEvaluator:
    """Own one fit's timestamp schedule and optional reusable worker pool."""

    def __init__(
        self,
        trajectory: CubicBSplineTrajectory,
        planes: BSplinePlaneReturns,
        workers: int,
    ) -> None:
        self.segment, fraction = trajectory.segments(planes.times_sec)
        self._basis = np.ascontiguousarray(
            cumulative_basis(fraction, trajectory.knot_spacing_sec)[0]
        )
        self._edges = np.unique(self.segment[:, None] + np.arange(3)[None, :])
        self._planes = planes
        self._domain = (
            trajectory.start_time_sec,
            trajectory.knot_spacing_sec,
            trajectory.control_point_count,
        )
        self._workers = min(workers, max(1, (len(self.segment) + 4095) // 4096))
        bounds = np.linspace(0, len(self.segment), self._workers + 1, dtype=np.int64)
        self._bounds = list(zip(bounds[:-1].tolist(), bounds[1:].tolist(), strict=True))
        self._pool = ThreadPoolExecutor(max_workers=self._workers) if self._workers > 1 else None
        controls = trajectory.control_point_count
        index = np.arange(controls)[:, None] + np.arange(-3, 4)[None, :]
        shape = (controls, 7, 6, 6)
        self._band_valid = np.broadcast_to(
            ((index >= 0) & (index < controls))[:, :, None, None], shape,
        )
        self._band_rows = np.broadcast_to(
            6 * np.arange(controls)[:, None, None, None] + np.arange(6)[None, None, :, None],
            shape,
        )[self._band_valid]
        self._band_columns = np.broadcast_to(
            6 * index[:, :, None, None] + np.arange(6)[None, None, None, :], shape,
        )[self._band_valid]
        self.identity = (
            f"calibrex.numba_bspline_planes/v0.3;numba={version('numba')};"
            f"workers={self._workers};fastmath=false;cache=true;parallel_pass=false;"
            "imu=shared_numpy;normal=numba_banded;covariance=numpy"
        )

    def close(self) -> None:
        """Release only this evaluator's worker pool, including on failed fits."""
        if self._pool is not None:
            self._pool.shutdown(wait=True)

    def normal_system(
        self, trajectory: CubicBSplineTrajectory, imu: _Linearization,
    ) -> tuple[csc_matrix, FloatArray]:
        """Accumulate local plane/IMU products without assembling their large Jacobian."""
        residual, local = self.evaluate(trajectory, derivatives=True)
        controls = trajectory.control_point_count
        control_columns = 6 * controls

        def chunk(bounds: tuple[int, int]) -> tuple[FloatArray, FloatArray]:
            lo, hi = bounds
            return cast(tuple[FloatArray, FloatArray], _plane_normal(
                self.segment[lo:hi], local[lo:hi], residual[lo:hi], controls,
            ))

        if self._pool is None:
            band, plane_gradient = chunk(self._bounds[0])
        else:
            chunk((0, 0))
            parts = list(self._pool.map(chunk, self._bounds))
            band, plane_gradient = parts[0]
            for other_band, other_gradient in parts[1:]:
                band += other_band
                plane_gradient += other_gradient
        parameters = imu.parameter_count
        coupling = np.zeros((control_columns, parameters - control_columns))
        calibration = np.zeros((parameters - control_columns, parameters - control_columns))
        gradient = np.zeros(parameters)
        groups: dict[tuple[int, int], list[tuple[IntArray, FloatArray]]] = {}
        for row, column, value in zip(imu.rows, imu.columns, imu.values, strict=True):
            groups.setdefault((int(row[0]), len(row)), []).append((column, value))
        for (offset, count), entries in groups.items():
            columns = np.column_stack([entry[0] for entry in entries])
            values = np.column_stack([entry[1] for entry in entries])
            local_columns = int(np.count_nonzero(columns[0] < control_columns))
            other_band, other_coupling, other_calibration, other_gradient = cast(
                tuple[FloatArray, FloatArray, FloatArray, FloatArray],
                _imu_normal(columns, values, imu.residuals[offset:offset + count],
                            controls, parameters, local_columns),
            )
            band += other_band
            coupling += other_coupling
            calibration += other_calibration
            gradient += other_gradient
        gradient[:control_columns] += plane_gradient
        control = coo_matrix(
            (band[self._band_valid], (self._band_rows, self._band_columns)),
            shape=(control_columns, control_columns),
        ).tocsc()
        return bmat(
            [[control, csc_matrix(coupling)],
             [csc_matrix(coupling.T), csc_matrix(calibration)]], format="csc",
        ), gradient

    def evaluate(
        self,
        trajectory: CubicBSplineTrajectory,
        *,
        derivatives: bool,
    ) -> tuple[FloatArray, FloatArray]:
        domain = (
            trajectory.start_time_sec,
            trajectory.knot_spacing_sec,
            trajectory.control_point_count,
        )
        if domain != self._domain:
            raise ValueError("compiled plane schedule requires the initial spline time domain")
        relative = np.zeros((trajectory.control_point_count - 1, 3, 3))
        # Only referenced edges are evaluated, preserving the native near-pi guard.
        relative[self._edges] = np.einsum(
            "tji,tjk->tik",
            trajectory.rotations[self._edges],
            trajectory.rotations[self._edges + 1],
        )
        delta = np.zeros((len(relative), 3))
        delta[self._edges] = so3_log_batch(relative[self._edges])
        log_jacobian = np.zeros_like(relative)
        if derivatives:
            log_jacobian[self._edges] = _right_jacobian(delta[self._edges], inverse=True)

        def chunk(bounds: tuple[int, int]) -> tuple[FloatArray, FloatArray]:
            lo, hi = bounds
            return cast(
                tuple[FloatArray, FloatArray],
                _plane_kernel(
                    trajectory.rotations,
                    trajectory.positions,
                    self.segment[lo:hi],
                    self._basis[lo:hi],
                    relative,
                    delta,
                    log_jacobian,
                    self._planes.points_body_m[lo:hi],
                    self._planes.plane_points_world_m[lo:hi],
                    self._planes.plane_normals_world[lo:hi],
                    self._planes.sigma_m,
                    derivatives,
                ),
            )

        if self._pool is None:
            return chunk(self._bounds[0])
        # Compile in the caller before dispatching the first concurrent call.
        chunk((0, 0))
        parts = list(self._pool.map(chunk, self._bounds))
        return np.concatenate([part[0] for part in parts]), np.concatenate(
            [part[1] for part in parts]
        )
